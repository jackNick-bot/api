//
//  ViewController.h
//  WebTry
//
//  Created by  on 2024/4/14.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic,strong) NSDictionary * dic;

@property (nonatomic,strong) UITextField *logTxt ;
@end

