 lipo -create /Users/sol/Library/Developer/Xcode/DerivedData/FeedbackDemo-fbqbntwfugjfeceydavembxeepxh/Build/Products/Debug-iphoneos/ZHTestSDKDemo.framework/ZHTestSDKDemo /Users/rrrr/Library/Developer/Xcode/DerivedData/FeedbackDemo-fbqbntwfugjfeceydavembxeepxh/Build/Products/Debug-iphonesimulator/ZHTestSDKDemo.framework/ZHTestSDKDemo  -output /Users/rrrr/Library/Developer/Xcode/DerivedData/FeedbackDemo-fbqbntwfugjfeceydavembxeepxh/Build/Products/hebin/hebin

open /Users/rrrr/Library/Developer/Xcode/DerivedData/FeedbackDemo-fbqbntwfugjfeceydavembxeepxh/Build/Products/hebin/hebin
